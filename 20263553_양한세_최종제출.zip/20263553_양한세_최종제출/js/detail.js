// detail.js — 문제 상세, 정답 보기, 댓글

document.addEventListener('DOMContentLoaded', () => {
    // detail.html이 아닌 경우 실행 안 함
    if (!document.getElementById('problem-detail')) return;

    const params = new URLSearchParams(window.location.search);
    const id = params.get('id');
    const problem = getProblemById(id);

    if (!problem) {
        document.getElementById('problem-detail').innerHTML = '<p>문제를 찾을 수 없습니다.</p>';
        return;
    }

    // 문제 렌더링
    document.getElementById('problem-title').textContent = problem.title;
    document.getElementById('problem-meta').textContent =
        `카테고리: ${categoryLabel(problem.category)} | 작성자: ${problem.author} | 날짜: ${problem.date}`;
    document.getElementById('problem-content').textContent = problem.content;

    // 정답 보기 버튼
    document.getElementById('show-answer-btn').addEventListener('click', () => {
        const box = document.getElementById('answer-box');
        box.style.display = box.style.display === 'none' ? 'block' : 'none';
        document.getElementById('answer-text').textContent = problem.answer;
    });

    // 댓글 렌더링
    renderComments(problem);

    // 댓글 등록
    const commentForm = document.getElementById('comment-form');
    if (commentForm) {
        commentForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const user = getCurrentUser();
            if (!user) {
                alert('댓글은 로그인 후 작성할 수 있습니다.');
                return;
            }
            const text = document.getElementById('comment-input').value.trim();
            if (!text) return;
            addComment(id, { author: user.username, text });
            document.getElementById('comment-input').value = '';
            renderComments(getProblemById(id));
        });
    }
});

function renderComments(problem) {
    const list = document.getElementById('comment-list');
    if (!list) return;
    list.innerHTML = '';
    if (problem.comments.length === 0) {
        list.innerHTML = '<li style="color:gray;">아직 댓글이 없습니다.</li>';
        return;
    }
    problem.comments.forEach(c => {
        const li = document.createElement('li');
        li.innerHTML = `<strong>${c.author}</strong> <span style="color:gray;font-size:12px;">${c.date}</span><br>${c.text}`;
        list.appendChild(li);
    });
}

function categoryLabel(cat) {
    return { free: '자유 문제', nonsense: '넌센스 문제', common: '상식 문제' }[cat] || cat;
}
