// auth.js — 회원가입 / 로그인 / 로그아웃 (localStorage 기반)

const USER_KEY = 'quiz_users';
const SESSION_KEY = 'quiz_current_user';

function getUsers() {
    return JSON.parse(localStorage.getItem(USER_KEY) || '[]');
}

function getCurrentUser() {
    return JSON.parse(sessionStorage.getItem(SESSION_KEY) || 'null');
}

function register(username, password) {
    const users = getUsers();
    if (users.find(u => u.username === username)) {
        return { success: false, message: '이미 사용 중인 아이디입니다.' };
    }
    users.push({ username, password });
    localStorage.setItem(USER_KEY, JSON.stringify(users));
    return { success: true };
}

function login(username, password) {
    const users = getUsers();
    const user = users.find(u => u.username === username && u.password === password);
    if (!user) {
        return { success: false, message: '아이디 또는 비밀번호가 틀렸습니다.' };
    }
    sessionStorage.setItem(SESSION_KEY, JSON.stringify({ username }));
    return { success: true };
}

function logout() {
    sessionStorage.removeItem(SESSION_KEY);
    window.location.href = 'index.html';
}

// 네비게이션 바 로그인 상태 반영 (모든 페이지 공통)
function updateNavAuth() {
    const user = getCurrentUser();
    const loginLink = document.querySelector('a[href="login.html"]');
    const signupLink = document.querySelector('a[href="signup.html"]');

    if (!loginLink) return;

    if (user) {
        loginLink.textContent = '로그아웃';
        loginLink.href = '#';
        loginLink.onclick = (e) => { e.preventDefault(); logout(); };
        if (signupLink) {
            signupLink.textContent = user.username + '님';
            signupLink.href = '#';
            signupLink.style.pointerEvents = 'none';
        }
    }
}

document.addEventListener('DOMContentLoaded', updateNavAuth);
