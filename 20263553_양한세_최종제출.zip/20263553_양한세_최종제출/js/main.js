// main.js — 메인 페이지 카드 렌더링 + 검색

document.addEventListener('DOMContentLoaded', () => {
    renderCategory('free', 'free-list');
    renderCategory('nonsense', 'nonsense-list');
    renderCategory('common', 'common-list');

    // 검색창 이벤트
    const searchBox = document.querySelector('.search-box');
    if (searchBox) {
        searchBox.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                const keyword = searchBox.value.trim();
                if (keyword) {
                    window.location.href = `search.html?q=${encodeURIComponent(keyword)}`;
                }
            }
        });
    }
});

function renderCategory(category, listId) {
    const ul = document.getElementById(listId);
    if (!ul) return;

    const problems = getProblemsByCategory(category).slice(-5).reverse(); // 최신 5개
    ul.innerHTML = '';

    if (problems.length === 0) {
        ul.innerHTML = '<li style="padding:10px;color:gray;">등록된 문제가 없습니다.</li>';
        return;
    }

    problems.forEach(p => {
        const li = document.createElement('li');
        li.innerHTML = `
            <a href="detail.html?id=${p.id}">
                ${p.title}
                <p>✍️ ${p.author} &nbsp; 📅 ${p.date} &nbsp; 💬 ${p.comments.length}</p>
            </a>
            <hr>
        `;
        ul.appendChild(li);
    });
}
