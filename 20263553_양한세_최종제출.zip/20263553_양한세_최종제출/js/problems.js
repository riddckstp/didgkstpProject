// problems.js — 문제 CRUD (localStorage 기반)

const STORAGE_KEY = 'quiz_problems';

// 샘플 초기 데이터
function initProblems() {
    if (getProblems().length === 0) {
        const samples = [
            {
                id: 1, category: 'free',
                title: '1 + 1은 얼마일까요?',
                content: '가장 기본적인 덧셈 문제입니다.',
                answer: '2',
                author: '관리자',
                date: '2026-06-01',
                comments: []
            },
            {
                id: 2, category: 'nonsense',
                title: '닭이 먼저냐, 달걀이 먼저냐?',
                content: '철학적 넌센스 문제!',
                answer: '닭! (달걀은 다리가 없어서 먼저 올 수 없다)',
                author: '관리자',
                date: '2026-06-02',
                comments: []
            },
            {
                id: 3, category: 'nonsense',
                title: '바나나를 영어로 하면?',
                content: '쉬운 것 같지만 함정이 있다!',
                answer: 'Banana (바나나)',
                author: '관리자',
                date: '2026-06-03',
                comments: []
            },
            {
                id: 4, category: 'common',
                title: '대한민국의 수도는?',
                content: '대한민국의 수도를 맞혀보세요.',
                answer: '서울',
                author: '관리자',
                date: '2026-06-04',
                comments: []
            },
            {
                id: 5, category: 'common',
                title: '물의 화학식은?',
                content: '중학교 과학 수준의 문제입니다.',
                answer: 'H₂O',
                author: '관리자',
                date: '2026-06-05',
                comments: []
            },
            {
                id: 6, category: 'free',
                title: '가장 큰 행성은?',
                content: '태양계에서 가장 큰 행성을 고르세요.',
                answer: '목성 (Jupiter)',
                author: '관리자',
                date: '2026-06-06',
                comments: []
            },
        ];
        localStorage.setItem(STORAGE_KEY, JSON.stringify(samples));
    }
}

function getProblems() {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
}

function getProblemById(id) {
    return getProblems().find(p => p.id === parseInt(id));
}

function getProblemsByCategory(category) {
    return getProblems().filter(p => p.category === category);
}

function addProblem(problem) {
    const problems = getProblems();
    const newId = problems.length > 0 ? Math.max(...problems.map(p => p.id)) + 1 : 1;
    const newProblem = {
        id: newId,
        comments: [],
        date: new Date().toISOString().slice(0, 10),
        ...problem
    };
    problems.push(newProblem);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(problems));
    return newProblem;
}

function addComment(problemId, comment) {
    const problems = getProblems();
    const idx = problems.findIndex(p => p.id === parseInt(problemId));
    if (idx === -1) return;
    problems[idx].comments.push({
        author: comment.author,
        text: comment.text,
        date: new Date().toISOString().slice(0, 10)
    });
    localStorage.setItem(STORAGE_KEY, JSON.stringify(problems));
}

function searchProblems(keyword) {
    const kw = keyword.trim().toLowerCase();
    if (!kw) return getProblems();
    return getProblems().filter(p =>
        p.title.toLowerCase().includes(kw) ||
        p.content.toLowerCase().includes(kw)
    );
}

initProblems();
